#!/bin/bash
# A bash script that starts two separate conky configurations
#
# this script is meant to start conky in a dualscreen configuration, meaning
#   the trees are placed right next to each other on the split of the monitors

# starts conky scripts
conky -dc ./conky_left_dualscreen.conf
conky -dc ./conky_right_dualscreen.conf
